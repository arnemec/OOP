package com.example.brownfrown

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.joda.time.DateTime
import java.io.File
import java.io.InputStream
import java.nio.file.Paths
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.*

class reportWindow : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report_window)
        val back: Button = findViewById(R.id.back)
        val fromToDate: TextView = findViewById(R.id.fromToDate)
        val frequencyText: TextView = findViewById(R.id.frequencyText)
        val consistencyText: TextView = findViewById(R.id.consistencyText)
        val timeOnToiletText: TextView = findViewById(R.id.timeOnToiletText)
        val painText: TextView = findViewById(R.id.painText)
        val bloodText: TextView = findViewById(R.id.bloodText)

        var frequencyNumber = 0

        var timeToiletSum = 0
        var consistencySum = 0
        var painSum = 0

        var consistencyAverage = 0
        var timeToiletAverage = 0
        var painAverage = 0

        var bloodPositiveCount = 0
        var bloodNegativeCount = 0
        
        val dateNow = SimpleDateFormat("dd. MM. yyyy").format(Date())
        var datePast = DateTime.now().minusDays(7)
        var dateNowBetter = SimpleDateFormat("yyyy-MM-dd").format(Date())

        var filesList = mutableListOf<String>()

        val datePastFormatted = datePast.toString("dd. MM. yyyy")
        fromToDate.text =  datePastFormatted + " – " + dateNow
        File("/storage/emulated/0/Android/data/com.example.brownfrown/cache/").list().forEach{
            val path: String = it.toString()
            filesList.add(path)
        }

        filesList.forEach{
            val inputStream: InputStream = File(
                "/storage/emulated/0/Android/data/com.example.brownfrown/cache",
                it
            ).inputStream()
            val lineList = mutableListOf<String>()
            inputStream.bufferedReader().useLines { lines -> lines.forEach { lineList.add(it)} }
            val date = lineList.elementAt(0)
            val time = lineList.elementAt(1)
            val toiletTime = lineList.elementAt(2)
            val consistency = lineList.elementAt(3)
            val pain = lineList.elementAt(4)
            val blood = lineList.elementAt(5)

            val dateInFile = LocalDate.parse(date)
            val today = LocalDate.parse(dateNowBetter)
            val days: Long = ChronoUnit.DAYS.between(dateInFile, today)

            if(days<7){
                frequencyNumber++
                timeToiletSum = timeToiletSum + toiletTime.toInt()
                consistencySum = consistencySum + consistency.toInt()
                painSum = painSum + pain.toInt()
                if(blood == "1"){
                    bloodPositiveCount++
                }
                else{
                    bloodNegativeCount++
                }
            }
        }

        if(frequencyNumber==0){
            Toast.makeText(applicationContext, "Za poslední týden je uloženo 0 záznamů, není možné vytvořit vyhodnocení", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        else {
            timeToiletAverage = timeToiletSum / frequencyNumber
            consistencyAverage = consistencySum / frequencyNumber
            painAverage = painSum / frequencyNumber

            frequencyText.text = when {
                frequencyNumber <= 2 -> "Tento týden jste byl/a na toaletě " + frequencyNumber.toString() + "x.\nPokud to pro Vás není normální, začněte jíst více\nvlákniny, pít více vody a suplementovat probiotika.\nPokud to nebude pomáhat, užijte projímadlo."
                frequencyNumber <= 21 -> "Tento týden jste byl/a na toaletě " + frequencyNumber.toString() + "x.\nToto je zdravý a pravidelný počet,\npodobně by to mělo pokračovat."
                else    -> "Tento týden jste byl/a na toaletě " + frequencyNumber.toString() + "x.\nToto je vysoký počet, ale pokud se nevyskytují\ndalší potíže, nemělo by to ničemu vadit."
            }

            timeOnToiletText.text = when {
                timeToiletAverage <= 15 -> "Váš průměrný čas strávený na toaletě je " + timeToiletAverage.toString() + " minut.\nTato doba je ideální, pokuste se\nmít podobný výsledek i příště!"
                timeToiletAverage <= 20 -> "Váš průměrný čas strávený na toaletě je " + timeToiletAverage.toString() + " minut.\nTato doba není špatná, ale ideálně by Vaše\nnávštěva toalety měla trvat maximálně 10 až 15 minut.\nZkuste to do budoucna změnit."
                timeToiletAverage <= 40 -> "Váš průměrný čas strávený na toaletě je " + timeToiletAverage.toString() + " minut. \nTato doba je příliš dlouhá, Vaše návštěva toalety\nby měla trvat maximálně 10 až 15 minut.\nPři takto dlouhých dobách strávených na toaletě\nse zvyšuje riziko vzniku hemoroidů."
                else -> "Váš průměrný čas strávený na toaletě je " + timeToiletAverage.toString() + " minut.\nTato doba je extrémně dlouhá, Vaše návštěva\ntoalety by měla trvat maximálně 10 až 15 minut.\nPři takto dlouhých dobách strávených na toaletě\nse výrazně zvyšuje riziko vzniku hemoroidů."
            }

            consistencyText.text = when {
                consistencyAverage <= 20 -> "Konzistence Vaší stolice bývá velmi řídká.\nPokud průjem přetrvává, nasaďte přísnou dietu.\nNutné je i pít dostatek tekutin a\nsuplementovat probiotika. Pokud průjem\nani poté neodezní, zkonzultujte lékaře. "
                consistencyAverage <= 39 -> "Konzistence Vaší stolice bývá často řidší.\nSnižte konzumaci například vlákniny a kofeinu.\nPotřebné je pít dostatek tekutin a suplementovat probiotika.\nPřísná dieta zatím není nutná."
                consistencyAverage <= 60 -> "Konzistence Vaší stolice je normální.\nUdržujte si stejnou stravu, jako doteď,\naby to tak bylo i do příště!"
                consistencyAverage <= 79 -> "Konzistence Vaší stolice bývá často tužší.\nMůžete zvýšit konzumaci například\nvlákniny a kofeinu, zkuste si i zacvičit.\nTaké zkuste pít více tekutin a suplementovat\nprobiotika."
                else -> "Konzistence Vaší stolice bývá velmi tuhá.\n Zkuste užívat projímadlo, ideálně přírodní.\nPomoci může i vláknina, švestky nebo kofein.\nMusíte pít dostatek tekutin a suplementovat\nprobiotika. Pokud se i přesto nic nezmění,\nzkonzultujte lékaře."
            }

            painText.text = when {
                painAverage == 0 -> "Žádná bolest se neobjevila.\nSnad to tak zůstane!"
                painAverage <= 25 -> "Objevila se lehká bolest.\nJe možné, že o nic nejde, ale radši\ndávejte pozor na zdroj bolesti."
                painAverage <= 50 -> "Objevila se střední bolest.\n Lokalizujte zdroj bolesti a zkuste\nv lékarně koupit vhodný přípravek.\nJestli se situace zhorší, nebo bude\ndlouho přetrvávat, navštivte lékaře."
                painAverage <= 75 -> "Objevila se vyšší bolest.\nLokalizujte zdroj bolesti a navštivte lékaře.\nLékař vám doporučí vhodnou léčbu. "
                else -> "Objevila se vysoká bolest.\nLokalizujte zdroj bolesti a co nejdříve\nnavštivte lékaře.\nLékař vám doporučí vhodnou léčbu."
            }

            bloodText.text = when {
                bloodPositiveCount == 0 -> "Krev se ve Vaší stolici neobjevila. Dobrá zpráva!"
                bloodPositiveCount <= 2 -> "Krev se ve Vaší stolici objevila " + bloodPositiveCount.toString() + "x.\nPokud to bude takto dále pokračovat,\nzvažte konzultaci s lékařem."
                bloodPositiveCount <= 5 -> "Krev se ve Vaší stolici objevila " + bloodPositiveCount.toString() + "x.\nKrev by mohla pocházet například z\nfisury,hemoroidů, nebo ze střev.\nPokud je to možné, navštivte lékaře."
                else -> "Krev se ve Vaší stolici objevila " + bloodPositiveCount.toString() + "x.\nKrev by mohla pocházet například\nz fisury, hemoroidu, nebo ze střev.\nCo nejdříve navštivte lékaře."
            }
        }

        back.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}