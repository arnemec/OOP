package com.example.brownfrown

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.InputStream
import java.nio.file.Path
import java.nio.file.Paths
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val newEntry: Button = findViewById(R.id.add)
        val report: Button = findViewById(R.id.report)
        val listView: ListView = findViewById(R.id.list)
        var filesList = mutableListOf<String>()


        val list = mutableListOf<String>()
        var date1 = SimpleDateFormat("yyyy_MM_dd_HHmmss").format(Date())
        date1 = "2021_04_27_113504"
        var text1 = "$date1.txt"
        var textFile1 = File(externalCacheDir, text1)
        textFile1.writeText("2021-04-27\n11:35\n19\n45\n0\n0")

        var date2 = SimpleDateFormat("yyyy_MM_dd_HHmmss").format(Date())
        date2 = "2021_04_25_190624"
        var text2 = "$date2.txt"
        var textFile2 = File(externalCacheDir, text2)
        textFile2.writeText("2021-04-25\n19:06\n24\n79\n20\n1")

        var date3 = SimpleDateFormat("yyyy_MM_dd_HHmmss").format(Date())
        date3 = "2021_04_28_0716"
        var text3 = "$date3.txt"
        var textFile3 = File(externalCacheDir, text3)
        textFile3.writeText("2021-04-28\n07:16\n21\n61\n10\n0")

        var date4 = SimpleDateFormat("yyyy_MM_dd_HHmmss").format(Date())
        date4 = "2021_04_26_202904"
        var text4 = "$date4.txt"
        var textFile4 = File(externalCacheDir, text4)
        textFile4.writeText("2021-04-26\n20:29\n15\n54\n0\n0")

        var date5 = SimpleDateFormat("yyyy_MM_dd_HHmmss").format(Date())
        date5 = "2021_04_24_120904"
        var text5 = "$date5.txt"
        var textFile5 = File(externalCacheDir, text5)
        textFile5.writeText("2021-04-24\n12:09\n27\n84\n32\n1")

        File("/storage/emulated/0/Android/data/com.example.brownfrown/cache/").list().forEach{
            val path: String = it.toString()
            filesList.add(path)
        }

        filesList.forEach{
        val inputStream: InputStream = File("/storage/emulated/0/Android/data/com.example.brownfrown/cache", it).inputStream()
            val lineList = mutableListOf<String>()
            inputStream.bufferedReader().useLines { lines -> lines.forEach { lineList.add(it)}
                val date = lineList.elementAt(0)
                val time = lineList.elementAt(1)
                list.add(0, date + "    " + time)
            }
        }
        Collections.sort(list)
        Collections.reverse(list)
        val adapter:ArrayAdapter<String> = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line, list
        )
        listView.adapter = adapter

    listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
        val selectedItem = parent.getItemAtPosition(position)
        var filesListCompare = mutableListOf<String>()
        File("/storage/emulated/0/Android/data/com.example.brownfrown/cache/").list().forEach{
            val path: String = it.toString()
            filesListCompare.add(path)
        }

        filesListCompare.forEach{
            val inputStream: InputStream = File(
                "/storage/emulated/0/Android/data/com.example.brownfrown/cache",
                it
            ).inputStream()

            var pathString: String = "/storage/emulated/0/Android/data/com.example.brownfrown/cache/" + it
            var path: Path = Paths.get(pathString)

            val lineListCompare = mutableListOf<String>()
            inputStream.bufferedReader().useLines { lines -> lines.forEach { lineListCompare.add(
                it
            )}
                val dateCompare = lineListCompare.elementAt(0)
                val timeCompare = lineListCompare.elementAt(1)

                val duration = lineListCompare.elementAt(2)
                val consistency = lineListCompare.elementAt(3)
                val pain = lineListCompare.elementAt(4)
                val blood = lineListCompare.elementAt(5)

                val fileCompare = dateCompare + "    " + timeCompare
                if(selectedItem == fileCompare){
                    itemChoose(adapter, list, position, path, dateCompare, timeCompare, duration, consistency, pain, blood)
                }
            }
        }
    }

    newEntry.setOnClickListener{
        val intent = Intent(this, entryWindow::class.java)
        startActivity(intent)
    }

    report.setOnClickListener{
        val intentNew = Intent(this, reportWindow::class.java)
        startActivity(intentNew)
    }
    }
    private fun itemChoose(adapter: ArrayAdapter<String>, list: MutableList<String>, position: Int, filePath: Path, date: String, time: String, duration: String, consistency: String, pain: String, blood: String)
    {
        lateinit var dialog: AlertDialog
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Záznam")
        var bloodYesNo = ""
        if (blood=="1"){
            bloodYesNo = "Ano"
        }
        else{
            bloodYesNo = "Ne"
        }
        builder.setMessage("Datum: $date        Čas: $time\n\nDoba na toaletě (min): $duration\n\nKonzistence (0 = nejřidší, 100 = nejtužší): $consistency\n\nBolest (0-100): $pain\n\nKrev: $bloodYesNo")

        val dialogClickListener = DialogInterface.OnClickListener{ _, which ->
        when(which){
            DialogInterface.BUTTON_POSITIVE ->
                if (true) {
                    list.removeAt(position)
                    var file: File = filePath.toFile()
                    adapter.notifyDataSetChanged()
                    file.delete()
                    Toast.makeText(applicationContext, "Odstraněno", Toast.LENGTH_SHORT).show()
                }
            DialogInterface.BUTTON_NEUTRAL ->
                if (true) {
                }
        }
    }
        builder.setPositiveButton("Odstranit záznam", dialogClickListener)
        builder.setNeutralButton("Zpět", dialogClickListener)
        dialog = builder.create()
        dialog.show()
    }
}