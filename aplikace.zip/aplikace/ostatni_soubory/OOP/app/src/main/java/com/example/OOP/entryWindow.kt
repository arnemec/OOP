package com.example.brownfrown

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.widget.*
import androidx.annotation.RequiresApi
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

class entryWindow : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entry_window)

        val send: Button = findViewById(R.id.send)
        val back: Button = findViewById(R.id.back)
        var bloodCheckNumber = 0;
        val painBar: SeekBar = findViewById(R.id.pain);
        val consistencyBar: SeekBar = findViewById(R.id.consistency);
        val dateText: EditText = findViewById(R.id.date);
        val timeText: EditText = findViewById(R.id.time);
        val timeToiletText: EditText = findViewById(R.id.timeOnToilet);
        val bloodCheck: CheckBox = findViewById(R.id.blood);

        send.setOnClickListener{
            if(timeToiletText.text.isNotEmpty() and dateText.text.isNotEmpty() and timeText.text.isNotEmpty()){
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                val painNumber = painBar.getProgress()
                val consistencyNumber = consistencyBar.getProgress();
                val dateInput = dateText.text
                val timeInput = timeText.text
                val timeToiletInput = timeToiletText.text

                var dateCheck = ""
                var timeCheck = ""

                var clones = 0

                val dateCompare = dateInput.toString()
                val timeCompare = timeInput.toString()

                if(bloodCheck.isChecked){
                    bloodCheckNumber = 1;
                }
                else{
                    bloodCheckNumber = 0;
                }

                var filesList = mutableListOf<String>()
                File("/storage/emulated/0/Android/data/com.example.brownfrown/cache/").list().forEach{
                    val path: String = it.toString()
                    filesList.add(path)
                }

                filesList.forEach{
                    val inputStream: InputStream = File(
                        "/storage/emulated/0/Android/data/com.example.brownfrown/cache",
                        it
                    ).inputStream()

                    val lineList = mutableListOf<String>()

                    inputStream.bufferedReader().useLines { lines -> lines.forEach { lineList.add(it)} }
                    dateCheck = lineList.elementAt(0)
                    timeCheck = lineList.elementAt(1)

                    if(dateCheck == dateCompare){
                        if(timeCheck == timeCompare){
                            clones++
                        }
                    }
                }

                if(clones == 0){
                        val date = SimpleDateFormat("yyyy_MM_dd_HHmmss").format(Date())
                        var text = "$date.txt"
                        var textFile = File(externalCacheDir, text)
                        textFile.writeText("$dateInput\n$timeInput\n$timeToiletInput\n$consistencyNumber\n$painNumber\n$bloodCheckNumber")
                        Toast.makeText(applicationContext, "Záznam uložen", Toast.LENGTH_SHORT).show()
                    }
                else{
                    Toast.makeText(applicationContext, "Neuloženo, počkejte alespoň minutu", Toast.LENGTH_SHORT).show()
                }

            }
            else{
                Toast.makeText(applicationContext, "Doplňte chybějící informace", Toast.LENGTH_SHORT).show()
            }
        }
        back.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val dateTimeNow = LocalDateTime.now();
        val dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        val timeFormat = DateTimeFormatter.ofPattern("HH:mm")
        val dateNow = dateTimeNow.format(dateFormat)
        val timeNow = dateTimeNow.format(timeFormat)

        dateText.text = Editable.Factory.getInstance().newEditable(dateNow);
        timeText.text = Editable.Factory.getInstance().newEditable(timeNow);
    }
}

